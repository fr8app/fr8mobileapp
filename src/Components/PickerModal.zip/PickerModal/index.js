import React, { useState } from "react";
import {
  SafeAreaView,
  Text,
  View,
  Image,
  StatusBar,
  Modal,
  Platform,
  Dimensions,
} from "react-native";

//STYLES IMPORT FROM STYLES FILE
import { styles } from "./styles";
import { Colors } from "../../Themes/colors";
import { styleConstants } from "../../Themes/constants.js";
// import { Picker } from '@react-native-community/picker';

import { Picker } from "@react-native-picker/picker";
import ScrollPicker from "react-native-picker-scrollview";
import { AppImages } from "../../Themes/appImages";
import { TouchableOpacity } from "react-native-gesture-handler";
import { WheelPicker } from "react-native-wheel-picker-android";
import DeviceInfo from "react-native-device-info";

export const PickerModal = (props) => {
  const {
    isDropdownVisible,
    title,
    selectedValueIndex,
    items,
    onSelect,
    onClose,
    onValueChange,
  } = props;
  const [selectedItem, setSeletcedItem] = useState(selectedValueIndex);
  const marginTopNotch =
    Platform.OS == "ios"
      ? DeviceInfo.hasNotch() == true
        ? Dimensions.get("screen").width * -0.03
        : "-4%"
      :  Dimensions.get("screen").width * 0.1;
  return (
    <Modal
      animated
      transparent
      visible={isDropdownVisible}
      animationType="fade"
    >
      <View style={styles.wrapper}>
        <View style={styles.outerContainer}>
          <View
            style={{
              ...styles.container,
              height:
                Platform.OS == "ios"
                  ? DeviceInfo.hasNotch() == true
                    ? Dimensions.get("screen").width * 0.475
                    : Dimensions.get("screen").width * 0.425
                  : Dimensions.get("screen").width * 0.425,
              marginBottom: 33,
            }}
          >
            <View style={styles.dropdownHeader}>
              <TouchableOpacity
                activeOpacity={0.4}
                onPress={onClose}
                style={styles.iconView}
              >
                <Text 
                  onPress={onClose}
                style={styles.optionText}>Cancel</Text>
              </TouchableOpacity>
              <Text
                maxFontSizeMultiplier={1}
                allowFontScaling={false}
                style={styles.headerTitle}
              >
                {title}
              </Text>
              <TouchableOpacity
                activeOpacity={0.4}
                onPress={() => onSelect(selectedItem)}
                style={styles.iconView}
              >
                <Text
                 onPress={() => onSelect(selectedItem)}
                style={{ ...styles.optionText, color: "#24A0ED" }}>
                  Select
                </Text>
              </TouchableOpacity>
            </View>
            <View style={{ ...styles.wheelPicker, marginTop: marginTopNotch }}>
              <WheelPicker
                selectedItem={selectedItem}
                data={items}
                onItemSelected={(index) => setSeletcedItem(index)}
                selectedItemTextColor={Colors.label}
                selectedItemTextFontFamily={styleConstants.fontFamily.semiBold}
                itemTextFontFamily={styleConstants.fontFamily.medium}
                itemTextColor={Colors.editText}
                indicatorColor="#ffffff"
                selectedItemTextSize={18}
              />
            </View>
          </View>
        </View>
      </View>
    </Modal>
  );
};
