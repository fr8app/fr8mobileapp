import React, { Component } from "react";
import {
    SafeAreaView,
    View,
    Dimensions,
} from "react-native";

import styles, { darkMap } from "./style";

import MapView, { PROVIDER_GOOGLE, Polyline, Marker } from "react-native-maps";
import geolocation from '@react-native-community/geolocation';
import { getPreciseDistance } from "geolib";

const height = Dimensions.get('screen').height
const width = Dimensions.get('screen').width


class MapComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            mapZoomin: 5,
            mapZoomout: 18,
            stop: false,
            pause: false,
            start: false,
            coordinates: [],
            distance: Number(0),
            prevLatlog: {},
            region: {
                latitude: 0,
                longitude: 0,
                latitudeDelta: 0,
                longitudeDelta: 0,
            },
            makeRoute: false,
            snapObj : null
        };

    }

    componentDidMount() {
        this.getLatLong()
    }

    getLatLong() {

        geolocation.watchPosition((position) => {
            const { latitude, longitude } = position.coords
            const newCoordinate = {
                latitude,
                longitude
            };
            // this.state.coordinate.timing(newCoordinate).start()
            if (!this.state.makeRoute) {
                this.setState({

                    region: {
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude,
                        longitudeDelta: 0.056,
                        latitudeDelta: 0.066
                    },
                    distance: this.state.distance + this.calcDistance(newCoordinate),
                    prevLatlog: newCoordinate
                })
            }

        });

        geolocation.getCurrentPosition(
            position => {
                let region = {
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude,
                    latitudeDelta: 1,
                    longitudeDelta: 0.0922
                };

                if (this.mapRef) {
                    this.mapRef.animateToRegion(region, 1000);
                }

                if (!this.state.makeRoute) {
                    this.setState(
                        {
                            region,
                            latitude: region.latitude,
                            longitude: region.longitude,
                            //   coordinates:this.state.coordinates.concat({
                            //     latitude: position.coords.latitude,
                            // longitude: position.coords.longitude
                            //   })
                        });

                }

            },
            error => {

                let region = {
                    latitude: 40.741231,
                    longitude: -74.101984,
                    latitudeDelta: 28.857763630813984,
                    longitudeDelta: 109.58674516528845
                };
                this.setState(
                    { region, latitude: region.latitude, longitude: region.longitude },
                    () => { }
                );

                if (this.mapRef) {
                    this.mapRef.animateToRegion(region, 1000);
                }
                // if (this.mapReff) {
                //     this.mapReff.animateToRegion(region, 2000)
                // }
            },
        );
    }

    changeLocation = (location) => {

        if (this.state.coordinates.length < 5) {
            // this.mapRef.fitToCoordinates(this.state.coordinates, { edgePadding: { top: 100, bottom: 100, right: 50, left: 50 }, animated: false })
        }
        // this.mapReff.fitToCoordinates(this.state.coordinates, { edgePadding: { top: 40, bottom: 40, right: 50, left: 50 }, animated: false })

        this.setState({
            coordinates: this.state.coordinates.concat({
                latitude: location.nativeEvent.coordinate.latitude,
                longitude: location.nativeEvent.coordinate.longitude
            }),
            region: {
                latitude: location.nativeEvent.coordinate.latitude,
                longitude: location.nativeEvent.coordinate.longitude,
                // latitudeDelta: 0.045,
                // longitudeDelta: 0.054
            }
        })
    }


    //distance calculate
    calcDistance = newLatlng => {
        return getPreciseDistance(newLatlng, this.state.prevLatlog) || 0
    }

    makeRoute() {
        this.setState({
            makeRoute: true
        }, () => {
            this.mapSnapRef.fitToCoordinates(this.state.coordinates, { edgePadding: { top: 20, bottom: 20, right: 20, left: 20 }, animated: false })
        });
    }

    takeSnap() {
        return new Promise((resolve , reject) => {
            this.mapSnapRef.takeSnapshot({                                                
                format: 'png',   // image formats: 'png', 'jpg' (default: 'png')
                quality: 1,    // image quality: 0..1 (only relevant for jpg, default: 1)
                result: 'file',   // result types: 'file', 'base64' (default: 'file')
            }).then((uri) => {
                resolve({
                                'uri': uri,
                                'region': this.state.region,
                                'distance': this.state.distance                        
                })
                
            }).catch((e) => reject('Unable to take snap'))  
        })        
    }

 
    render() {
        return (
            <View style={{flex:1 , alignItems : 'center' , justifyContent:'center'}}>
                {!this.state.makeRoute && 
                <MapView
                    minZoomLevel={10}
                    maxZoomLevel={20}
                    showsUserLocation={!this.state.makeRoute ? true : false}
                    ref={mapRef => (this.mapRef = mapRef)}
                    style={[styles.map]}
                    customMapStyle={darkMap}
                    provider={PROVIDER_GOOGLE}
                    customMapStyle={darkMap}

                    region={{
                        latitude: this.state.region.latitude,
                        longitude: this.state.region.longitude,
                        latitudeDelta: 0.005,
                        longitudeDelta: 0.005
                    }}

                    onUserLocationChange={!this.state.makeRoute ? (location) => this.changeLocation(location) : () => { }}
                >

                    {
                        this.state.makeRoute && <Polyline
                            coordinates={this.state.coordinates}
                            strokeColor="#bf8221"
                            // strokeColors={['#bf8221', '#ffe066', '#ffe066', '#ffe066', '#ffe066',]}
                            strokeWidth={3}
                        />
                    }
                    {
                        this.state.makeRoute &&
                        <Marker
                            coordinate={this.state.coordinates[0]}
                            pinColor={'blue'}
                        />}
                    {this.state.makeRoute && <Marker
                        coordinate={this.state.region}
                    />}

                </MapView>
                    }
                {this.state.makeRoute && 
                <View style={{
                    height: 210,
                    width : '100%'
                }}>
                    <MapView
                        minZoomLevel={10}
                        maxZoomLevel={20}
                        showsUserLocation={!this.state.makeRoute ? true : false}
                        ref={mapRef => (this.mapSnapRef = mapRef)}
                        style={[styles.map]}
                        customMapStyle={darkMap}
                        provider={PROVIDER_GOOGLE}
                        customMapStyle={darkMap}
                        initialRegion={{
                            latitude: this.state.region.latitude,
                            longitude: this.state.region.longitude,
                            latitudeDelta: 0.005,
                            longitudeDelta: 0.005
                        }}                 
                        onUserLocationChange={!this.state.makeRoute ? (location) => this.changeLocation(location) : () => { }}
                    >

                        {
                            this.state.makeRoute && <Polyline
                                coordinates={this.state.coordinates}
                                strokeColor="#bf8221"
                                // strokeColors={['#bf8221', '#ffe066', '#ffe066', '#ffe066', '#ffe066',]}
                                strokeWidth={3}
                            />
                        }
                        {
                            this.state.makeRoute &&
                            <Marker
                                coordinate={this.state.coordinates[0]}
                                pinColor={'blue'}
                            />}
                        {this.state.makeRoute && <Marker
                            coordinate={this.state.region}
                        />}

                    </MapView>
                </View>
                }
            </View>
        );
    }
}

export default MapComponent;
