import React, { Component } from 'react';
import { View, Text, SafeAreaView, AppState, Image } from 'react-native';
import MapComponent from './mapComponent';
import { Inputs, Button, Header, Loader, LiveStreamRender, DataManager } from "./../../Components";
import { AppImages } from "./../../Themes";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import { CreatePostAction } from '../../Redux/actions/RoutePostAction'
import moment from "moment";
import Timer from '../../Components/Timer';
import TimeLineBtns from './timeLineBtns';

class NewTimeline extends Component {
    static navigationOptions = ({ navigation }) => {
        return {
            header: (
                <Header
                    headerTitle={'Timeline'}
                    leftImageSource={AppImages.images.back}
                    leftbackbtnPress={() => navigation.goBack()}
                />
            )
        };
    };

    constructor(props) {
        super(props);
        this.state = {
            imgSource: ''
        };

        this.timerRef = null;
        this.mapRef = null;

    }

    componentDidMount = () => {
        AppState.addEventListener('change', this._handleAppStateChange);
    };


    _handleAppStateChange = async (nextAppState) => {
        if (
            this.state.appState.match(/inactive|background/) &&
            nextAppState === 'active'
        ) {
            console.log('App has come to the foreground!');
            this.timerRef.getBackgroundTime();
            // DataManager.setCallTime(null)

            if (this.timerInterval === null) {
                console.log('Start interval in Foreground');
                this.callInterval();
            }
        } else {
            DataManager.setCallTime(Date.now());
            clearInterval(this.timerInterval);
            this.timerInterval = null;
        }
        // this.setState({ appState: nextAppState });
    };


    //set timer interval
    callInterval = () => {
        this.timerInterval = null;
        this.timerInterval = setInterval(async () => {
            if (this.timerRef) {
                this.timerRef.add();
            }
        }, 1000);
    };

    startTrack() {
        this.callInterval();
    }


    pauseTrack() {
        clearInterval(this.timerInterval);
        this.timerInterval = null;
        AppState.removeEventListener('change', this._handleAppStateChange);
    }

    stopTrack() {
        this.mapRef.makeRoute();
        let time = this.timerRef.getTotalTime();
        setTimeout(() => {
          
                this.mapRef.takeSnap()
                .then((data) => {
                    console.log('data in stop track', data)
    
                    var a = time.split(':'); // split it at the colons
                    var seconds = (+a[0]) * 60 * 60 + (+a[1]) * 60 + (+a[2]);
        
                    this.props.CreatePostAction(this.props.navigation.state.params.terminalId, parseInt(data.distance), seconds, data.uri, this.timelineBtnRef.getStartTime(), moment().format('HH:mm'), this.props.navigation)
                })
                              

        }, 1000);
    }


    render() {
        return (
            <SafeAreaView style={{ flex: 1, backgroundColor: '#000' }}>

                {/* Main Map Component  */}
                <MapComponent ref={refs => this.mapRef = refs} />


                {/* Timer  */}
                <View style={{
                    position: 'absolute',
                    top: 10,
                    alignSelf: 'center'
                }}>
                    <Timer ref={refs => this.timerRef = refs} />
                </View>

                {/* Btns Component  */}
                <View style={{
                    position: 'absolute',
                    bottom: 30,
                    alignSelf: 'center'
                }}>
                    <TimeLineBtns
                        startTrack={() => this.startTrack()}
                        pauseTrack={() => this.pauseTrack()}
                        stopTrack={() => this.stopTrack()}
                        ref={refs => this.timelineBtnRef = refs}
                    />
                </View>


            </SafeAreaView>
        );
    }
}

function mapStateToProps(state) {
    return {
        routeState: state.RoutePostData,

    };
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators({ CreatePostAction }, dispatch);
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(NewTimeline);


