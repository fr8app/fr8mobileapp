import React, { Component } from 'react';
import {
    View,
    FlatList,
    SafeAreaView,
    Image,
    Text,
    TextInput
} from 'react-native';
import styles from './styles'
import { Header, LiveStreamRender } from './../../Components';
import { AppStyles, AppConstants, AppImages } from './../../Themes';
import { OTPublisher, OTSubscriber, OTSession, OTSubscriberView } from 'opentok-react-native'

const sessionId = '1_MX40NjI5Mzk2Mn5-MTU2NjQ3OTExMzE0OX5Ea3VGUFFzaHdiUnlZaUV3YUNCbGQyMmJ-fg';
const token = "T1==cGFydG5lcl9pZD00NjI5Mzk2MiZzaWc9NDE5YjllMmRkOGE5NGY5NzA0NzRhNGJlNjEzMzU2NjZkMzg3MjQ5NDpzZXNzaW9uX2lkPTFfTVg0ME5qSTVNemsyTW41LU1UVTJOalEzT1RFeE16RTBPWDVFYTNWR1VGRnphSGRpVW5sWmFVVjNZVU5DYkdReU1tSi1mZyZjcmVhdGVfdGltZT0xNTY2NDc5MTMwJm5vbmNlPTAuMDg3NTY4MjczNDM4NjM0OTQmcm9sZT1wdWJsaXNoZXImZXhwaXJlX3RpbWU9MTU2OTA3MTEyOSZpbml0aWFsX2xheW91dF9jbGFzc19saXN0PQ==";
const apiKey = "46293962"

class LiveStreams extends Component {
    static navigationOptions = ({ navigation }) => {
        return {
            header: null
            //  <Header
            //     headerTitle={AppConstants.constants.Live_Streams}
            //     leftImageSource={AppImages.images.back} leftbackbtnPress={() => navigation.goBack()}
            //     rightImageSource={AppImages.images.add} rightBackBtnPress={() => navigation.navigate("Publisher")} />
        }
    };

    constructor(props) {
        super(props);
        this.state = {
            searchText: null,
            subscriberResult: []
        }

        this.publisherProperties = {
            publishAudio: false,
            cameraPosition: 'front',
            name: ''
        };
        this.publisherEventHandlers = {
            streamCreated: event => {
                console.log('Publisher stream created!', event);
            },
            streamDestroyed: event => {
                console.log('Publisher stream destroyed!', event);
            },
        };
    
        let updatedValue = []
        this.sessionEventHandlers = {
            streamCreated: async (event) => {
                console.log("called", event)
                await updatedValue.push(event)
                if (this.state.subscriberResult.length > 0) {
                    let response = this.state.subscriberResult
                    for (let j in updatedValue) {
                        for (let i in response) {
                            if (response[i].streamId !== updatedValue[j].streamId) {
                                response.push(updatedValue[j])
                            }
                        }
                    }
                }
                else {
                    let response = []
                    response.push(event)
                    this.setState({ subscriberResult: response })
                }
                // this.setState({ subscriberResult: response })
            },

            streamDestroyed: event => {
                console.log("called", event)
                let response = this.state.subscriberResult
                for (let i in response) {
                    if (response[i].streamId == event.streamId) {
                        response.splice(i, 1)
                    }

                }
                this.setState({ subscriberResult: response })
            },
            signal:(evet)=>{
                console.log(evet)
            }
        };



    }

    _renderItem = ({ item, index }) => (
        <LiveStreamRender
            fullName={"User Full Name"}
            userSource={AppImages.images.user01}
            postSource={AppImages.images.image01}

        />

    );

    render() {
        return (
            <View style={{ flex: 1, justifyContent: "center", marginTop: 50 }}>
                
                <OTSession apiKey={apiKey} sessionId={sessionId} token={token} eventHandlers={this.sessionEventHandlers} />
                 <View style={[AppStyles.container, { paddingHorizontal: 20 }]}>

                    <FlatList
                        bounces={false}
                        contentContainerStyle={{ paddingTop: 10 }}
                        data={this.state.subscriberResult}
                        extraData={[this.state, this.state.subscriberResult]}
                        renderItem={this._renderItem}
                        showsVerticalScrollIndicator={false}
                        keyExtractor={(item, index) => index.toString()}
                    />

                 </View>
          
             </View> 
        )
    }
}

export default LiveStreams;