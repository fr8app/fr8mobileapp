import { StyleSheet, Dimensions } from 'react-native'
import { Colors } from '../../Themes/colors'
import { styleConstants } from '../../Themes/constants.js'

export const styles = StyleSheet.create({
    wrapper: {
        flex: 1,
        justifyContent: 'flex-end',
        backgroundColor: 'rgba(0,0,0,0.5)',
    },
    outerContainer: {
        backgroundColor: Colors.white,
        borderTopLeftRadius: styleConstants.borderRadiusBig,
        borderTopRightRadius: styleConstants.borderRadiusBig,
        paddingBottom: '3%'
    },
    container: {
        width: Dimensions.get('screen').width,
    },
    dropdownHeader: {
        flexDirection: 'row',
        padding: Dimensions.get('screen').width * 0.025,
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    headerTitle: {
        fontSize: styleConstants.fontSize.medium,
        fontFamily: styleConstants.fontFamily.medium,
        color: Colors.primary,
        textAlign: 'center',
    },
    optionView: {
        // width: Dimensions.get('screen').width * 0.0575,
        // height: Dimensions.get('screen').width * 0.0575,
    },
    optionText: {
        color: Colors.privacyText,
        fontSize:styleConstants.fontSize.medium
    },
    listItemView: {
        // flex: 1,
        // width: Dimensions.get('screen').width,
        // height: Dimensions.get('screen').height * 0.15,
        // alignItems: 'center',

    },
    itemTextStyle: {
        flex: 1,
        textAlign: 'center',
        textAlignVertical: 'center',
        fontSize: styleConstants.fontSize.medium,
        fontFamily: styleConstants.fontFamily.normal,
        color: Colors.slotText,
    },
    wheelPicker: {
        alignItems: 'center',
    },

})
