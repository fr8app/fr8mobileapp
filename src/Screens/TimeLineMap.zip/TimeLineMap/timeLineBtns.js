import React, { Component } from 'react';
import { View, Text, Image, TouchableHighlight , AppState } from 'react-native';
import AppImages from '../../Themes/AppImages';
import moment from 'moment';


class TimeLineBtns extends Component {
  constructor(props) {
    super(props);
    this.state = {
        showStart : true,
        showStop : false,
        showPause : false,
        startTime : ''        
    };
  }

  getStartTime()
  {
      return this.state.startTime
  }

  renderStartBtn()
  {
      return(
        <TouchableHighlight onPress={() => {            
            this.setState({
                    showPause : true,
                    showStart : false,
                    showStop : false,
                    startTime : this.state.startTime == '' ? moment().format('HH:mm') : this.state.startTime
                });
                this.props.startTrack();
            }}
            underlayColor={'transparent'}
        >
            <Image 
                source={AppImages.images.start}            
                style={{ height: 100, width: 100 }} resizeMode='contain'            
            />
        </TouchableHighlight>
      )
  }

  renderStopBtn()
  {
      return(
        <TouchableHighlight onPress={() => this.props.stopTrack()}
            underlayColor={'transparent'}
            >
            <Image 
                source={AppImages.images.stop}            
                style={{ height: 80, width: 80 }} resizeMode='contain'            
            />
        </TouchableHighlight>
      )
  }
  renderPauseBtn()
  {
      return(
        <TouchableHighlight onPress={() => {this.setState({
                                                showPause : false,
                                                showStart : true,
                                                showStop : true
                                            });
                                            this.props.pauseTrack();
    }}
        underlayColor={'transparent'}
        >
            <Image 
                source={AppImages.images.pause}            
                style={{ height: 100, width: 100 }} resizeMode='contain'            
            />
        </TouchableHighlight>
      )
  }

  render() {
    return (
      <View style={{
          flexDirection : 'row',
          alignItems:'center'
      }}>   
          {this.state.showStart && this.renderStartBtn()}
          {this.state.showStop && this.renderStopBtn()}
          {this.state.showPause && this.renderPauseBtn()}
      </View>
    );
  }
}

export default TimeLineBtns;
